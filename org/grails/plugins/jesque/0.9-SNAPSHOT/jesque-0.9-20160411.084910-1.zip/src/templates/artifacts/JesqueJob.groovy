@artifact.package@
class @artifact.name@ {

    def perform() {
        //todo: I will work hard for you, but are the sneakers really that much cheaper?!
    }
}
